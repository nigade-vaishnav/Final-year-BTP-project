# Entry point for running the full pipeline
print('Run your pipeline here')